//
//  Vattanac_Bank_Payment_Gateway.h
//  Vattanac Bank Payment Gateway
//
//  Created by Phana Chhean on 6/9/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Vattanac_Bank_Payment_Gateway.
FOUNDATION_EXPORT double Vattanac_Bank_Payment_GatewayVersionNumber;

//! Project version string for Vattanac_Bank_Payment_Gateway.
FOUNDATION_EXPORT const unsigned char Vattanac_Bank_Payment_GatewayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Vattanac_Bank_Payment_Gateway/PublicHeader.h>


